package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Inte;
import dao.InteDao;

public class InteUpdateFormAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		int inte_number = Integer.parseInt(request.getParameter("inte_number"));
		String pageNum = request.getParameter("pageNum");

		InteDao id=InteDao.getInstance();
		Inte inte=id.select(inte_number);
		
		request.setAttribute("inte_number",inte_number);
		request.setAttribute("pageNum",pageNum);
		request.setAttribute("inte",inte);
		
		return "inteUpdateForm.jsp";
	}
}