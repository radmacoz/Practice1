package service;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.List;
import java.util.StringTokenizer;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.Admin;
import dao.AdminDao;
import dao.Agent;
import dao.AgentDao;
import dao.Goods;
import dao.GoodsDao;

public class GoodsUpdateAction  implements CommandProcess {  
	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		 System.out.println("xxxxxxGoodsUpdateActionxxxxxxxxxxxxxxxxxxxxxxxxx");
		 MultipartRequest mr = null;
		 String saveDirectory = "upload"; 
		 try {
			mr = new MultipartRequest(request, request.getRealPath(saveDirectory)  , 1024*1024*20, "utf-8", new DefaultFileRenamePolicy());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 
		 String flg = ""; 
		 flg = mr.getParameter("flg")==null?"":mr.getParameter("flg"); 
		 
		 System.out.println("flg = "+ flg);
		 if("".equals( flg )){
			 flg = "IL";
		 }  
		  
		 AdminDao ad = AdminDao.getInstance();
		 Admin vo = new Admin();
		 List<Admin> listAllGoodsKind = ad.selectAllGoodsKind();
		 request.setAttribute("listAllGoodsKind", listAllGoodsKind); 
		 
		 //지역조회 left  
		 List<Admin> list = ad.selectGu();
	     request.setAttribute("list", list);  
 	            
		 List<Admin> listDong = ad.selectAllDong("");
		 request.setAttribute("listDong", listDong);  
  
		 List<Admin> listOp = ad.selectOption();
		 request.setAttribute("listOp", listOp);  
  
		 //center    
		 List<Admin> clist = ad.selectGu();
	     request.setAttribute("clist", clist); 
 	     String inguCode = mr.getParameter("guCode")==null?"":mr.getParameter("guCode"); 
	     if(inguCode.equals("")) inguCode = "1";  
		 List<Admin> clistDong = ad.selectDong(inguCode);
		 request.setAttribute("clistDong", clistDong);  
		 request.setAttribute("guCode", inguCode);  
		 
 		 request.setAttribute("flg",  flg); 
 		 
		 GoodsDao gDao = GoodsDao.getInstance();
		 Goods gVo = new Goods();
		 //입력 / 수정  
		 if("I".equals(flg) || "U".equals(flg)){  
			  
			 System.out.println("getParameterValues"+ mr.getParameterValues("options"));
			 
			 String[] options = mr.getParameterValues("options");
			 String strOp = "";
			 if(options != null){
				 System.out.println("options.length = "+ options.length);
				 
				 for(int i = 0; i<options.length; i++)
				 {
					 strOp += options[i];
					  
					 if(i<options.length-1){
						 strOp += "|";  
					 }   
				 }
			 }
			 System.out.println("strOp = "+ strOp);
			 gVo.setOptions(strOp);	  
			 gVo.setTitle(mr.getParameter("title"));
			  
			 gVo.setKindNo(Integer.parseInt(mr.getParameter("kindNo").equals("")?"1":mr.getParameter("kindNo")));
  
			 gVo.setTran("".equals(mr.getParameter("tran"))?new BigDecimal(0):new BigDecimal(mr.getParameter("tran")));                                                 
			 gVo.setRealLiveAmt(new BigDecimal("".equals(mr.getParameter("realLiveAmt"))?"0":mr.getParameter("realLiveAmt")));                                     
			 gVo.setLoan(new BigDecimal("".equals(mr.getParameter("loan"))?"0":mr.getParameter("loan")));
			 gVo.setNowDepositAmt(new BigDecimal("".equals(mr.getParameter("nowDepositAmt"))?"0":mr.getParameter("nowDepositAmt")));                                              
			 gVo.setNowGuarantyAmt(new BigDecimal("".equals(mr.getParameter("nowGuarantyAmt"))?"0":mr.getParameter("nowGuarantyAmt")));                                    
			 gVo.setMonthlyAmt(new BigDecimal("".equals(mr.getParameter("monthlyAmt"))?"0":mr.getParameter("monthlyAmt")));                                       
			 gVo.setSupplyArea(new BigDecimal("".equals(mr.getParameter("supplyArea"))?"0":mr.getParameter("supplyArea")));                                           
			 gVo.setTotalLayer(new BigDecimal("".equals(mr.getParameter("totalLayer"))?"0":mr.getParameter("totalLayer")));                                           
			 gVo.setApplyLayer(new BigDecimal("".equals(mr.getParameter("applyLayer"))?"0":mr.getParameter("applyLayer")));                                           
			 gVo.setTotalHouseholds(new BigDecimal("".equals(mr.getParameter("totalHouseholds"))?"0":mr.getParameter("totalHouseholds")));                                        
			 gVo.setDirection(mr.getParameter("direction"));                                       
			 gVo.setParkingCount(Integer.parseInt( "".equals(mr.getParameter("parkingCount"))?"0":mr.getParameter("parkingCount")));                                          
			 gVo.setCompletionYear(mr.getParameter("completionYear"));                                     
			 gVo.setHeaterType(mr.getParameter("heaterType"));                                       
			 gVo.setFuel(mr.getParameter("fuel"));                                                 
			 gVo.setLivePossibleDate(mr.getParameter("livePossibleDate"));                                           
		  
			 gVo.setAgentId(mr.getParameter("agentId").equals("")?1:Integer.parseInt(mr.getParameter("agentId")));
			 
 			 gVo.setDongCode(mr.getParameter("dongCode"));   
			 gVo.setGuCode(mr.getParameter("guCode"));                                                 
			 gVo.setMagmexp(mr.getParameter("magmexp"));                                                  
			 gVo.setDiversionArea(mr.getParameter("diversionArea"));                                           
			 gVo.setRoomCount(mr.getParameter("roomCount"));                                         
			 gVo.setBathroomCount(mr.getParameter("bathroomCount"));
			 gVo.setAddr(mr.getParameter("addr"));
			    
			 int i = 0;
			 if("I".equals(flg)){
				 i = gDao.insertGoods(gVo);    
				 gVo.setMaxNo(i);
				 System.out.println(" insertGoods i   ["+i+"]");
			 }else {
				 gVo.setGoodsNo(Integer.parseInt( mr.getParameter("goodsNo")));
				 i = gDao.updateGoods(gVo); 
				 gVo.setMaxNo(gVo.getGoodsNo()); 
			 }

			 if(i > 0)
			 { 
		 		 request.setAttribute("result",  "success");
		 		 request.setAttribute("msg",  "저장 성공 했습니다.");
		 	 
			 }else {
				 request.setAttribute("result",  "fail");  
			 	 request.setAttribute("msg",  "저장 실패 했습니다."); 
			 } 
			 if(i > 0){
				//입력 수정시 무조건 삭제 실행 한다. 사용자 불편함 감수 
				 i = gDao.deletePicture(gVo);
				 
			   int aa = 0;
			   //전송한 파일 정보를 가져와 출력한다
			   Enumeration files = mr.getFileNames();   
			   //파일 정보가 있다면 
			   while(files.hasMoreElements()){
			      //input 태그의 속성이 file인 태그의 name 속성값 :파라미터이름
			      String name = (String)files.nextElement();   
			       
			      //서버에 저장된 파일 이름
			      String filename = mr.getFilesystemName(name); 
			       
			      String originName = mr.getOriginalFileName("picture["+aa+"]");
			      
			       System.out.println("originName == "+ originName);
			       System.out.println("name == "+ name);
			       
			      if(name.equals("picture[5]") && originName != null){
			    	  gVo.setPictureName("06"+filename);
			      }else {
			    	  gVo.setPictureName(filename);
			      }
				  gVo.setPicturePath(request.getContextPath()+"/"+saveDirectory);
 
				   if(null != filename){  
					 i = gDao.insertPicture(gVo);  
			      }  
			   }
			 } 
 	
			 return "result.jsp";
			 
		 }else if("S".equals(flg)){  
			 gVo.setGoodsNo(Integer.parseInt(mr.getParameter("goodsNo")));
			 Goods outVo = gDao.selGoodsInfo(gVo);
			 request.setAttribute("rs", outVo); 
 
			 String ttext = outVo.getOptions();  
			 ArrayList<Goods> addOp = new ArrayList<>(); 
			 
			 String temp = outVo.getOptions();  
			 String[] values = temp.split("\\|");  
			 for(int i=0 ; i < values.length; i++ ) {
				 if(!"|".equals(values[i])){
					 Goods inOp = new Goods();
					 inOp.setOptions(values[i]); 
					 addOp.add(inOp);
				 }  
			 } 
			 
			 request.setAttribute("addOp", addOp);
			 
			 List<Goods> viewPicture = gDao.selListPicture(gVo);
			 request.setAttribute("viewPicture", viewPicture);
			 String bigPicture = "";
			  
			 for( int i =0 ; i<viewPicture.size(); i++){
				  bigPicture = viewPicture.get(i).getPictureName().substring(0,2);
				 if(bigPicture.equals("06")){
					 bigPicture = viewPicture.get(i).getPictureName().substring(2);
					 request.setAttribute("bigPicture", "/RMS/upload/"+bigPicture);
				 }
			 }
			 System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			 //agent select
			 Agent ag = new Agent();
			 AgentDao ado = AgentDao.getInstance(); 
			 int agentId = outVo.getAgentId();
			 System.out.println("select agentId = "+agentId);
			 if(0 != agentId){
				 ag = ado.select(agentId);
				 request.setAttribute("ag", ag);
			 }  
			 System.out.println("select end ");
			 
		 }else if("L".equals(flg)){
			 return "goodsList.jsp";
		 }else if("L".equals(flg)){
			 return "goodsList.jsp";
		 }else if("D".equals(flg)){
			 gVo.setGoodsNo(Integer.parseInt(mr.getParameter("goodsNo")));
			  
				int  i = gDao.deleteGoods(gVo);  
				 if(i > 0)
				 { 
			 		 request.setAttribute("result",  "success");
			 		 request.setAttribute("msg",  "삭제 성공 했습니다.");
			 	 
				 }else {
					 request.setAttribute("result",  "fail");  
				 	 request.setAttribute("msg",  "삭제 실패 했습니다."); 
				 } 
			//사진 삭제 
				System.out.println("del picture getGoodsNo = " + gVo.getGoodsNo() );
		        i = gDao.deletePicture(gVo);
				System.out.println("del picture i = " + i );
				
			 return "result.jsp";
		 } 
		 System.out.println("xxxxxxxGoodsUpdateAction end xxxxxxxxxxxxxxxxxxxxxxxx");	 
		 return "goodsUpdate.jsp";
	}
 
}
