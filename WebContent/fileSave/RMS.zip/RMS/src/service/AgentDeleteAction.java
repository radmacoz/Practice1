package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Agent;
import dao.AgentDao;

public class AgentDeleteAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		int agent_id=Integer.parseInt(request.getParameter("agent_id"));
		String pageNum = request.getParameter("pageNum");
		
		AgentDao ad=AgentDao.getInstance();
		int result=ad.delete(agent_id);
		
		List<Agent> list2 = ad.select();
		
		request.setAttribute("pageNum",pageNum);
		request.setAttribute("result",result);
		request.setAttribute("list2",list2);
		
		return "agentDelete.jsp";
	}
}