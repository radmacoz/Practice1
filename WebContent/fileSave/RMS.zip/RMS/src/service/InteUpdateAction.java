package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Inte;
import dao.InteDao;

public class InteUpdateAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		int inte_number = Integer.parseInt(request.getParameter("inte_number"));
		String pageNum = request.getParameter("pageNum");
		
		Inte inte=new Inte();
		inte.setInte_number(inte_number);
		
		inte.setInte_title(request.getParameter("inte_title"));
		inte.setInte_type(request.getParameter("inte_type"));
		inte.setInte_area(Double.valueOf(request.getParameter("inte_area")));
		inte.setInte_comment(request.getParameter("inte_comment"));
		inte.setPicture_no(request.getParameter("picture_no"));
				
		InteDao id=InteDao.getInstance();
		int result=id.update(inte);
		
		request.setAttribute("pageNum",pageNum);
		request.setAttribute("inte_number",inte_number);
		request.setAttribute("result",result);
		
		return "inteUpdate.jsp";
	}
}