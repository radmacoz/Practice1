package service;

import java.io.File;
import java.io.IOException;
import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;

import dao.Inte;
import dao.InteDao;
import dao.Picture;
import dao.PictureDao;

public class InteWriteAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		PictureDao pd=PictureDao.getInstance();
		
		int result1=0;
		String name=null,fileName=null;
		int maxSize=20*1024*1024;
		String saveDirectory="upload";
		String real=request.getContextPath()+"/"+saveDirectory;
		
//		gVo.setPicturePath(request.getContextPath()+"/"+saveDirectory);
		
		
		MultipartRequest mr=null;
		
		try {
			mr=new MultipartRequest(request,request.getRealPath(saveDirectory),maxSize,"utf-8",new DefaultFileRenamePolicy());
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
		
		int inte_number=Integer.parseInt(mr.getParameter("inte_number"));
		String inte_title=mr.getParameter("inte_title");
		String inte_type=mr.getParameter("inte_type");
		Double inte_area=Double.valueOf(mr.getParameter("inte_area"));
		String inte_comment=mr.getParameter("inte_comment");
		int agent_id=Integer.parseInt(mr.getParameter("agent_id"));
		String pageNum = request.getParameter("pageNum");
		
		Inte inte=new Inte();
		
		inte.setInte_number(inte_number);
		inte.setInte_title(inte_title);
		inte.setInte_type(inte_type);
		inte.setInte_area(inte_area);
		inte.setInte_comment(inte_comment);
		inte.setWrite_ip(request.getRemoteAddr());
		inte.setAgent_id(agent_id);
		
		InteDao id=InteDao.getInstance();
		int result=id.insert(inte);
		System.out.println("11111111111111111111인테리어 index 값 : "+result);
		
		Enumeration files=mr.getFileNames();
		
		Picture picture=new Picture();
//		File file=new File(real+"/"+fileName);
		
		while(files.hasMoreElements()) {
			name=(String)files.nextElement();
			fileName=mr.getFilesystemName(name);
			if(fileName!=null) {
				picture.setPicture_name(fileName);				
				picture.setPicture_path(real);
				picture.setGubun("I");
				picture.setGubun_no(result);
				
				System.out.println("2222222222222222인테리어 index 값 : "+result);

				result1=pd.insert(picture);
			}
//			String originName=mr.getOriginalFileName("picture_no["+ +"]");

		}
		//picture.setReg_date(reg_date);
		//picture.setGubun_no(gubun_no);
		//String[] fileName=mr.getParameterValues("picture_no");
		
		System.out.println("파일업로드 성공");
		
/****************************/
/*  주석 있던 곳. 복잡해서 치워버림	*/
/****************************/

		request.setAttribute("pageNum",pageNum);
		request.setAttribute("result",result);
		
		return "inteWrite.jsp";
	}
}










/*
		Enumeration files = mr.getFileNames();
		// 파일 정보가 있다면
		while (files.hasMoreElements()) {
			// input 태그의 속성이 file인 태그의 name 속성값 :파라미터이름
			String name = (String) files.nextElement();
			System.out.println(aa + " : name  == " + name);
			// 서버에 저장된 파일 이름
			String filename = mr.getFilesystemName(name);

			System.out.println(aa + " : filename  == " + filename);
			String originName = mr.getOriginalFileName("picture[" + aa + "]");
			System.out.println(aa + " : originName  == " + originName);
			gVo.setPictureName(filename);
			gVo.setPicturePath(request.getContextPath() + "/" + saveDirectory);

			System.out.println(aa + " : request.getContextPath()  == " + request.getContextPath());

			if (null != filename) {
				if (i > 0) {
					gVo.setMaxNo(i);
					i = gDao.insertPicture(gVo);
				}
			}
		}
		
		
		Inte inte=new Inte();
		
		inte.setInte_number(Integer.parseInt(request.getParameter("inte_number")));		// 지금 현재 여기 null값이 들어가고 있음
		inte.setInte_title(request.getParameter("inte_title"));
//		inte.setReg_date(request.getParameter("reg_date"));
		inte.setInte_type(request.getParameter("inte_type"));
		inte.setInte_area(Double.valueOf(request.getParameter("inte_area")));			// 위에 number주석하니 여기가 null?
		inte.setInte_comment(request.getParameter("inte_comment"));
//		inte.setInte_del_yn(request.getParameter("del_yn"));
//		inte.setInte_count(Integer.parseInt(request.getParameter("inte_count")));
		inte.setWrite_ip(request.getRemoteAddr());
		inte.setAgent_id(Integer.parseInt(request.getParameter("agent_id")));
//		inte.setPicture_no(request.getParameter("picture_no"));
///		inte.setPicture_no(request.getParameterValues("picture_no"));
		String pageNum = request.getParameter("pageNum");
				
		InteDao id=InteDao.getInstance();
		int result=id.insert(inte);
		
//		request.setAttribute("result",result);
*/