package service;  
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Admin;
import dao.AdminDao;
import dao.Goods;
import dao.GoodsDao;
public class GoodsAction implements CommandProcess {

	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		 
		 String flg = request.getParameter("flg")==null?"":request.getParameter("flg");
		  
		  
		 AdminDao ad = AdminDao.getInstance();
		 Admin vo = new Admin();
		 List<Admin> listAllGoodsKind = ad.selectAllGoodsKind();
		 request.setAttribute("listAllGoodsKind", listAllGoodsKind); 
		 
		 //지역조회  
		 List<Admin> list = ad.selectGu();
	     request.setAttribute("list", list); 
	      
		 List<Admin> listDong = ad.selectAllDong(""); 
		 request.setAttribute("listDong", listDong);  
		 
		 if( flg.equals("L")){
			 GoodsDao gDao = GoodsDao.getInstance();
			 Goods gVo = new Goods(); 
			 
			 String inGuDongCode = request.getParameter("inGuDongCode"); //구동코드
			 String start_no = "1";
			 if(null != request.getParameter("start_no")  && !request.getParameter("start_no").equals("")){
				 start_no = request.getParameter("start_no");
			 } 
			 String end_no = "50";
			 if(null != request.getParameter("end_no") && !request.getParameter("end_no").equals(""))
			 {
				 end_no = request.getParameter("end_no");
			 } 
			 int inKindNo = 0;  
			 if(null != request.getParameter("inKindNo") && !"".equalsIgnoreCase(request.getParameter("inKindNo")))
			 {
				 inKindNo = Integer.parseInt( request.getParameter("inKindNo"));
			 } 
			 String inDongCode = "";
			 if(null != request.getParameter("inDongCode") && !request.getParameter("inDongCode").equals(""))
			 {
				 inDongCode = request.getParameter("inDongCode");
			 }else{
				 inDongCode = "";
			 }
			  
			 gVo.setInKindNo(inKindNo);
			 gVo.setInDongCode(inDongCode);
			   
			String pageNum = request.getParameter("pageNum"); 
			
			if (pageNum == null || pageNum.equals("")) 
				pageNum = "1";
			int currentPage = Integer.parseInt(pageNum); 
			int rowPerPage  = 10;
			int pagePerBlk  = 10;	
		    int startRow    = (currentPage - 1) * rowPerPage + 1; 
		    int endRow      = startRow + rowPerPage - 1; 
		    
			 gVo.setStart_no(startRow);
			 gVo.setEnd_no(endRow);
			  
			 List<Goods> goodslist = gDao.selListGoods(gVo);
			 int total = 0;
			 if(goodslist.size() > 0 ){
				 total = goodslist.get(0).getToTal();
			 } 
			int totalPage   = (int)Math.ceil((double)total/rowPerPage); 
			int startPage=(currentPage - 1) / pagePerBlk * pagePerBlk + 1; 
			int endPage = startPage + pagePerBlk - 1;    
			if (endPage > totalPage) endPage = totalPage; 
				

			request.setAttribute("rowPerPage",rowPerPage);
			request.setAttribute("pagePerBlk",pagePerBlk);
			request.setAttribute("currentPage",currentPage); 
			request.setAttribute("totalPage",totalPage);
			request.setAttribute("startPage",startPage);
			request.setAttribute("endPage",endPage); 
			
		     request.setAttribute("goodslist", goodslist); 
		     request.setAttribute("start_no", start_no); 
		     request.setAttribute("end_no", end_no); 
		     request.setAttribute("inKindNo", inKindNo);  
		     request.setAttribute("inDongCode", inDongCode); 
		     
		     if(goodslist.size() > 0){
		    	 request.setAttribute("total", goodslist.get(0).getToTal());
		  	 }else {
		 		request.setAttribute("total", 0);
		 	 }
		      	 
			 return "goodsList.jsp";
		 }else if(flg.equals("IL")){
			 return "goodsUpdate.jsp";
		 }
			   	 
		 return "goodsList.jsp";
	}

}
