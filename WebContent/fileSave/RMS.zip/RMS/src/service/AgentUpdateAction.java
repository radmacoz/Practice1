package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Agent;
import dao.AgentDao;

public class AgentUpdateAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		int agent_id = Integer.parseInt(request.getParameter("agent_id"));
		String pageNum = request.getParameter("pageNum");
		
		Agent agent=new Agent();
		agent.setAgent_id(agent_id);
		
		AgentDao ad=AgentDao.getInstance();
		List<Agent> list2 = ad.select();
		
		agent.setEmail(request.getParameter("email"));;
		agent.setTel(request.getParameter("tel"));
		agent.setSns_no(Integer.parseInt(request.getParameter("sns_no")));
		agent.setAgent_type(request.getParameter("agent_type"));
//		agent.setDong_code(request.getParameter("dong_code"));
		agent.setChat_yn(request.getParameter("chat_yn"));
		agent.setAgent_comment(request.getParameter("agent_comment"));
		
		AgentDao id=AgentDao.getInstance();
		int result=id.update(agent);
		
		request.setAttribute("pageNum",pageNum);
		request.setAttribute("agent_id",agent_id);
		request.setAttribute("result",result);		
		request.setAttribute("list2",list2);
		
		return "agentUpdate.jsp";
	}
}