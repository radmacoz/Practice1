package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Inte;
import dao.InteDao;
import dao.Picture;
import dao.PictureDao;

public class InteViewAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		int inte_number=Integer.parseInt(request.getParameter("inte_number"));
		String pageNum=request.getParameter("pageNum");
		
		InteDao id=InteDao.getInstance();
		Inte inte=id.select(inte_number);
		
		if(inte!=null)
			id.updateHit(inte_number);
		
		int gubun_no=Integer.parseInt(request.getParameter("inte_number"));
		
		PictureDao pd=PictureDao.getInstance();
		Picture picture=pd.select(gubun_no);
		
		request.setAttribute("inte_number",inte_number);
		request.setAttribute("pageNum",pageNum);
		request.setAttribute("inte",inte);
		request.setAttribute("picture",picture);
		
		return "inteView.jsp";
	}
}