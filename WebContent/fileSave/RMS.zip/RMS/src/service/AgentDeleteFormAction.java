package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Agent;
import dao.AgentDao;

public class AgentDeleteFormAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		int agent_id = Integer.parseInt(request.getParameter("agent_id"));
		String pageNum=request.getParameter("pageNum");
		
		AgentDao ad=AgentDao.getInstance();
		List<Agent> list2 = ad.select();
		
		request.setAttribute("agent_id",agent_id);
		request.setAttribute("pageNum",pageNum);
		request.setAttribute("list2",list2);
		
		return "agentDeleteForm.jsp";
	}
}