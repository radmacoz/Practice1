package service;
  
import java.util.*;
import java.io.*;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
 
import dao.Admin;
import dao.AdminDao; 

public class AdminAction implements CommandProcess {
 
	@Override
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		  
		 response.setContentType("text/html;charset=UTF-8");
		 String saveDirectory = "upload"; 
		   
		 MultipartRequest mr = null;
	   try { 
		   String flg1= request.getParameter("flg")==null?"":request.getParameter("flg");

			 System.out.println("flg1 == "+ flg1);
		   if(flg1.equals("L")){     
				 return this.listPro(mr, request, response);
		   } 
		  mr = new MultipartRequest(request, request.getRealPath(saveDirectory) , 1024*1024*20, "utf-8", new DefaultFileRenamePolicy());
			
		 AdminDao ad = AdminDao.getInstance();
		 Admin vo = new Admin();
		  
		 String flg = mr.getParameter("flg"); 
		 String cudFlg = mr.getParameter("cudFlg");
		 String inGuCode = mr.getParameter("inGuCode"); //구코드
		 String inGuName = mr.getParameter("inGuKoName"); //구한글명 
		 String selGuCode = mr.getParameter("selGuCode"); //구코드 삭제
		 
		 String inGuDongCode = mr.getParameter("inGuDongCode"); //구동코드
		 String inDongCode = mr.getParameter("inDongCode");  //동코드
		 String inDongKoName = mr.getParameter("inDongKoName"); //동한글명
		 String selDongCode = mr.getParameter("selDongCode");  //동코드 삭제
		  
		 String inGoodsKindCode = mr.getParameter("inGoodsKindCode"); //방 타입 코드 
		 String inGoodsKindEnName = mr.getParameter("inGoodsKindEnName"); //방 타입 영문명 
		 String inGoodsKindKoName = mr.getParameter("inGoodsKindKoName"); //방 타입 한글명
		 String selGoodsKindCode = mr.getParameter("selGoodsKindCode"); //방 타입 코드 
		  
		 String inSnsKoName = mr.getParameter("inSnsKoName");
		 String selSnsNo = mr.getParameter("selSnsNo");

		 String inOptionKoName = mr.getParameter("inOptionKoName");
		 String selOptoinNo = mr.getParameter("selOptoinNo");
		  
		 System.out.println("flg == "+ flg);
		 System.out.println("cudFlg == "+ cudFlg);
		 System.out.println("inGuCode == "+ inGuCode); 
		 System.out.println("inGuName == "+ inGuName);
		 System.out.println("selGuCode == "+ selGuCode); 
		 System.out.println("#################################### ");  
		 System.out.println("inGuDongCode == "+ inGuDongCode); 
		 System.out.println("inDongCode == "+ inDongCode); 
		 System.out.println("inDongKoName == "+ inDongKoName); 
		 System.out.println("selDongCode == "+ selDongCode);
		 System.out.println("#################################### ");   
		 System.out.println("inGoodsKindCode == "+ inGoodsKindCode);   
		 System.out.println("inGoodsKindEnName == "+ inGoodsKindEnName);   
		 System.out.println("inGoodsKindKoName == "+ inGoodsKindKoName); 
		 System.out.println("selGoodsKindCode == "+ selGoodsKindCode);
		 System.out.println("#################################### ");  
		 System.out.println("inSnsKoName == "+ inSnsKoName);
	   
		 if(flg.equals("L")){  
			 return this.listPro(mr, request , response);
			 
		 }else if(flg.equals("I")){  
			 if(cudFlg.equals("gu") && !inGuCode.equals("")){ 
				 vo.setGuCode(inGuCode); 
				 vo.setGuKoName(inGuName);
				 if(ad.selectCheck(vo)){
					if(1 == ad.insert(vo)){ 
						request.setAttribute("msg", "입력 성공했습니다.");
					}else {
						request.setAttribute("msg", "입력 실패했습니다.");
					}
				 }else {
					 request.setAttribute("msg", "기존에 존재합니다");
				 }
			 }
			 //동입력
			 if(cudFlg.equals("dong") && !inDongCode.equals("")){
				 vo.setGuCode(inGuDongCode);
				 vo.setDongCode(inDongCode); 
				 vo.setDongKoName(inDongKoName);
				 if(ad.selectDongCheck(vo)){
					if(1== ad.insertDong(vo)){
						request.setAttribute("msg", "입력 성공했습니다.");
					}else {
						request.setAttribute("msg", "입력 실패했습니다.");
					}
				 }else {
					 request.setAttribute("msg", "기존에 존재합니다"); 
				 }
			 }
			     
			 //방타입 이력  
			 if(cudFlg.equals("goodsKind") && !inGoodsKindCode.equals("")){
 				 vo.setKindCode(inGoodsKindCode);
				 vo.setKindEnName(inGoodsKindEnName);
				 vo.setKindKoName(inGoodsKindKoName);
				 
				 if(1 == ad.insertGoodsKind(vo)){
					 request.setAttribute("msg", "입력 성공했습니다.");
				 }else {
					 request.setAttribute("msg", "입력 실패했습니다.");
			     } 
			 }
			 //sns 입력 
			 if(cudFlg.equals("sns") ){  
				   //전송한 파일 정보를 가져와 출력한다
				   Enumeration files = mr.getFileNames();   
				   //파일 정보가 있다면
				   while(files.hasMoreElements()){
				      //input 태그의 속성이 file인 태그의 name 속성값 :파라미터이름
				      String name = (String)files.nextElement();   
				      System.out.println("name  == "+ name);
				      //서버에 저장된 파일 이름
				      String filename = mr.getFilesystemName(name);  
				      System.out.println("filename  == "+ filename); 
					   vo.setSnsEnName(filename); 
					   vo.setPictureName(filename);
				   }
				 
				   vo.setPicturePath(request.getContextPath()+"/"+saveDirectory);
				   vo.setSnsKoName(inSnsKoName); 
		            
				   if(1 == ad.insertSns(vo)){
					   request.setAttribute("msg", "입력 성공했습니다.");
				    }else {
					   request.setAttribute("msg", "입력 실패했습니다.");
				   } 
			 }
			 	 
			 //option 입력 
			 if(cudFlg.equals("option") && inOptionKoName != null && !inOptionKoName.equals("")){   
				   vo.setOptionKoName(inOptionKoName);
				  
				   if(1 == ad.insertOption(vo)){
					   request.setAttribute("msg", "입력 성공했습니다.");
				    }else {
					   request.setAttribute("msg", "입력 실패했습니다.");
				   } 
			 } 
			  
		 }else if(flg.equals("D")){ 
 
			 if(cudFlg.equals("gu") && selGuCode != null && !selGuCode.equals("")){
			    vo.setGuCode(selGuCode);
				if (1 == ad.delete(vo)) {
					request.setAttribute("msg", "삭제 성공했습니다.");
				} else {
					request.setAttribute("msg", "삭제 실패했습니다.");
				}
			 }
			 
			 if(cudFlg.equals("dong") && selDongCode != null && !selDongCode.equals("")){
				 vo.setGuCode(inGuDongCode);
				 vo.setDongCode(selDongCode);
				 
				 if(1 == ad.deleteDong(vo)){
					 request.setAttribute("msg", "삭제 성공했습니다.");
				 }else {
					 request.setAttribute("msg", "삭제 실패했습니다.");
				 }
			 }
			 
			//방타입 삭제  
			 if(cudFlg.equals("goodsKind") && !selGoodsKindCode.equals("")){

				 System.out.println("selGoodsKindCode == "+ selGoodsKindCode);    
				 vo.setKindCode(selGoodsKindCode); 
				 
				 if(1 == ad.deleteGoodsKind(vo)){
					 request.setAttribute("msg", "삭제 성공했습니다.");
				 }else {
					 request.setAttribute("msg", "삭제 실패했습니다.");
			     } 
			 }   
			 
			 if(cudFlg.equals("sns") && selSnsNo != null && !selSnsNo.equals("")){   
				 vo.setSnsNo(Integer.parseInt(selSnsNo));
				 if(1 == ad.deleteSns(vo)){
					 request.setAttribute("msg", "삭제 성공했습니다.");
				 }else {
					 request.setAttribute("msg", "삭제 실패했습니다.");
			     } 
			 } 
			 
			 if(cudFlg.equals("option") && selOptoinNo != null && !selOptoinNo.equals("")){   
				   vo.setOptionNo(Integer.parseInt(selOptoinNo));
				  
				   if(1 == ad.deleteOption(vo)){
					   request.setAttribute("msg", "삭제 성공했습니다.");
				    }else {
					   request.setAttribute("msg", "삭제 실패했습니다.");
				   } 
			 }
		 } 
		 } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
	     } //입력 성공 후 조회  
		 request.setAttribute("flg", "L"); 
		 return this.listPro(mr, request, response);
	}
	 
	public String listPro(MultipartRequest mr, HttpServletRequest request, HttpServletResponse response) {
		String inGuDongCode = "";
		if(null == mr){
			inGuDongCode = request.getParameter("inGuDongCode"); //구동코드
		  }else {
			  inGuDongCode = mr.getParameter("inGuDongCode"); //구동코드  
		  }
		  
		 AdminDao ad = AdminDao.getInstance();
		 Admin vo = new Admin();
		 List<Admin> list = ad.selectGu();
	     request.setAttribute("list", list); 

		//동 조회   
		 if(inGuDongCode == null || inGuDongCode.equals("")) inGuDongCode = "1";
		 List<Admin> listDong = ad.selectDong(inGuDongCode); 
		 List<Admin> listAllDong = ad.selectAllDong(inGuDongCode);
		 request.setAttribute("listDong", listDong); 
		 request.setAttribute("listAllDong", listAllDong);  
		 request.setAttribute("inGuDongCode", inGuDongCode);
		 
		 //방타입 조회 
		 List<Admin> listAllGoodsKind = ad.selectAllGoodsKind();
		 request.setAttribute("listAllGoodsKind", listAllGoodsKind); 
		 //sns 조회
		 List<Admin> listAllSns = ad.selectAllSns();
		 request.setAttribute("listAllSns", listAllSns); 
		 //option 조회 
		 List<Admin> listAllOption = ad.selectOption();
		 request.setAttribute("listAllOption", listAllOption); 
		  
		 return "admin.jsp";
	}
 
}
