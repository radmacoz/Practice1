package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Inte;
import dao.InteDao;

public class InteWriteFormAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		int inte_number=0; 
		String pageNum = request.getParameter("pageNum");
		
		if (request.getParameter("inte_number") != null) {
			inte_number = Integer.parseInt(request.getParameter("inte_number"));
			
			InteDao id=InteDao.getInstance();
			Inte inte=id.select(inte_number);
		}
		
		request.setAttribute("inte_number",inte_number);
		request.setAttribute("pageNum",pageNum);	
		
		return "inteWriteForm.jsp";
	}
}