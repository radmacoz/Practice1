package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import dao.Agent;
//import dao.AgentDao;

public class AgentInsertFormAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		int agent_id=0;
		String pageNum = request.getParameter("pageNum");

		if(request.getParameter("agent_id")!=null) {
			agent_id=Integer.parseInt(request.getParameter("agent_id"));		
//			AgentDao ad=AgentDao.getInstance();
//			Agent agent=ad.select(agent_id);
		}
		
		request.setAttribute("agent_id",agent_id);
		request.setAttribute("pageNum",pageNum);

		return "agentInsertForm.jsp";
	}
}