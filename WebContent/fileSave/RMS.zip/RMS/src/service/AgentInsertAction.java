package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.Agent;
import dao.AgentDao;

public class AgentInsertAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		try {
			request.setCharacterEncoding("utf-8");
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		
		Agent agent=new Agent();
		
		agent.setAgent_id(Integer.parseInt(request.getParameter("agent_id")));
		agent.setPassword(request.getParameter("password"));
		agent.setName(request.getParameter("name"));
		agent.setEmail(request.getParameter("email"));
		agent.setTel(request.getParameter("tel"));
		agent.setMoney(Integer.parseInt(request.getParameter("money")));
		agent.setAgent_type(request.getParameter("agent_type"));
		agent.setChat_yn(request.getParameter("chat_yn"));
		agent.setSns_no(Integer.parseInt(request.getParameter("sns_no")));
		agent.setAgent_comment(request.getParameter("agent_comment"));
		String pageNum = request.getParameter("pageNum");

		AgentDao ad=AgentDao.getInstance();
		int result=ad.insert(agent);
		
		request.setAttribute("result",result);
		request.setAttribute("pageNum",pageNum);

		return "agentInsert.jsp";
	}
}