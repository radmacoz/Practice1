package service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.InteDao;


public class InteDeleteAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {
		int inte_number=Integer.parseInt(request.getParameter("inte_number"));
		String pageNum = request.getParameter("pageNum");
		
		InteDao id=InteDao.getInstance();
		int result= id.delete(inte_number);
		
		request.setAttribute("pageNum",pageNum);
		request.setAttribute("result",result);
		
		return "inteDelete.jsp";
	}
}