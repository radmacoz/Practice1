package service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.Agent;
import dao.AgentDao;

public class LoginAction implements CommandProcess {
	public String requestPro(HttpServletRequest request, HttpServletResponse response) {		
		int agent_id=Integer.parseInt(request.getParameter("agent_id"));
		String password=request.getParameter("password");

		HttpSession session=request.getSession();

		AgentDao ad=AgentDao.getInstance();
		Agent agent=(Agent)session.getAttribute("agent");

		agent=ad.selectList(agent_id,password);
		int result=ad.check(agent_id,password);


		if(result==1) {
			session.setAttribute("agent_id",agent_id);
			session.setAttribute("password",password);
		}
		
		List<Agent> list2 = ad.select();
		
		request.setAttribute("result",result);
		request.setAttribute("list2",list2);
		
		return "login.jsp";
	}
}