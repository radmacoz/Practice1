package dao;

import java.math.BigDecimal;

public class Goods {		
		private int start_no;
		private int end_no;
		private int toTal;
		private int inKindNo;
		private int agentId;  
		private int parkingCount;                   
		private int goodsNo;
		private int kindNo = 0;     
	    private int maxNo = 0;
		private String title = "";                 
		private BigDecimal tran;                  
		private BigDecimal realLiveAmt;           
		private BigDecimal loan;                  
		private BigDecimal nowDepositAmt;         
		private BigDecimal nowGuarantyAmt;        
		private BigDecimal monthlyAmt;            
		private BigDecimal supplyArea;            
		private BigDecimal totalLayer;            
		private BigDecimal applyLayer;            
		private BigDecimal totalHouseholds;       
		private String direction;                  
		private String completionYear;            
		private String heaterType;                
		private String fuel;                      
		private String livePossibleDate;          
		private String options;                    
		private String dongCode;                  
		private String guCode;                    
		private String magmexp;                   
		private String diversionArea;             
		private String roomCount;                 
		private String bathroomCount;
		private String addr; 
		private String inDongCode; 
		private String pictureName;
		private String picturePath;		 
		private String agent;  
		  
		private String kindKoName;//종류한글명
		private String kuKoNanme;  //구한글명
		private String dongKoName; //동한글명
		private String agentName;  
		  
		public String getKindKoName() {
			return kindKoName;
		}
		public void setKindKoName(String kindKoName) {
			this.kindKoName = kindKoName;
		}
		public String getKuKoNanme() {
			return kuKoNanme;
		}
		public void setKuKoNanme(String kuKoNanme) {
			this.kuKoNanme = kuKoNanme;
		}
		public String getDongKoName() {
			return dongKoName;
		}
		public void setDongKoName(String dongKoName) {
			this.dongKoName = dongKoName;
		}
		public String getAgentName() {
			return agentName;
		}
		public void setAgentName(String agentName) {
			this.agentName = agentName;
		}
		public int getMaxNo() {
			return maxNo;
		}
		public void setMaxNo(int maxNo) {
			this.maxNo = maxNo;
		}
		public String getPicturePath() {
			return picturePath;
		}
		public void setPicturePath(String picturePath) {
			this.picturePath = picturePath;
		}
		public int getInKindNo() {
			return inKindNo;
		}
		public void setInKindNo(int inKindNo) {
			this.inKindNo = inKindNo;
		}
		public int getToTal() {
			return toTal;
		}
		public void setToTal(int toTal) {
			this.toTal = toTal;
		}
		public String getAgent() {
			return agent;
		}
		public void setAgent(String agent) {
			this.agent = agent;
		}
		public String getPictureName() {
			return pictureName;
		}
		public void setPictureName(String pictureName) {
			this.pictureName = pictureName;
		}
		public int getGoodsNo() {
			return goodsNo;
		}
		public void setGoodsNo(int goodsNo) {
			this.goodsNo = goodsNo;
		}
		public int getStart_no() {
			return start_no;
		}
		public void setStart_no(int start_no) {
			this.start_no = start_no;
		}
		public int getEnd_no() {
			return end_no;
		}
		public void setEnd_no(int end_no) {
			this.end_no = end_no;
		}
		public String getInDongCode() {
			return inDongCode;
		}
		public void setInDongCode(String inDongCode) {
			this.inDongCode = inDongCode;
		} 
		public String getAddr() {
			return addr;
		}
		public void setAddr(String addr) {
			this.addr = addr;
		}
		public String getTitle() {
			return title;
		}
		public void setTitle(String title) {
			this.title = title;
		}
		public int getKindNo() {
			return kindNo;
		}
		public void setKindNo(int kindNo) {
			this.kindNo = kindNo;
		}
		public BigDecimal getTran() {
			return tran;
		}
		public void setTran(BigDecimal tran) {
			this.tran = tran;
		}
		public BigDecimal getRealLiveAmt() {
			return realLiveAmt;
		}
		public void setRealLiveAmt(BigDecimal realLiveAmt) {
			this.realLiveAmt = realLiveAmt;
		}
		public BigDecimal getLoan() {
			return loan;
		}
		public void setLoan(BigDecimal loan) {
			this.loan = loan;
		}
		public BigDecimal getNowDepositAmt() {
			return nowDepositAmt;
		}
		public void setNowDepositAmt(BigDecimal nowDepositAmt) {
			this.nowDepositAmt = nowDepositAmt;
		}
		public BigDecimal getNowGuarantyAmt() {
			return nowGuarantyAmt;
		}
		public void setNowGuarantyAmt(BigDecimal nowGuarantyAmt) {
			this.nowGuarantyAmt = nowGuarantyAmt;
		}
		public BigDecimal getMonthlyAmt() {
			return monthlyAmt;
		}
		public void setMonthlyAmt(BigDecimal monthlyAmt) {
			this.monthlyAmt = monthlyAmt;
		}
		public BigDecimal getSupplyArea() {
			return supplyArea;
		}
		public void setSupplyArea(BigDecimal supplyArea) {
			this.supplyArea = supplyArea;
		}
		public BigDecimal getTotalLayer() {
			return totalLayer;
		}
		public void setTotalLayer(BigDecimal totalLayer) {
			this.totalLayer = totalLayer;
		}
		public BigDecimal getApplyLayer() {
			return applyLayer;
		}
		public void setApplyLayer(BigDecimal applyLayer) {
			this.applyLayer = applyLayer;
		}
		public BigDecimal getTotalHouseholds() {
			return totalHouseholds;
		}
		public void setTotalHouseholds(BigDecimal totalHouseholds) {
			this.totalHouseholds = totalHouseholds;
		}
		public String getDirection() {
			return direction;
		}
		public void setDirection(String direction) {
			this.direction = direction;
		}
		public int getParkingCount() {
			return parkingCount;
		}
		public void setParkingCount(int parkingCount) {
			this.parkingCount = parkingCount;
		}
		public String getCompletionYear() {
			return completionYear;
		}
		public void setCompletionYear(String completionYear) {
			this.completionYear = completionYear;
		}
		public String getHeaterType() {
			return heaterType;
		}
		public void setHeaterType(String heaterType) {
			this.heaterType = heaterType;
		}
		public String getFuel() {
			return fuel;
		}
		public void setFuel(String fuel) {
			this.fuel = fuel;
		}
		public String getLivePossibleDate() {
			return livePossibleDate;
		}
		public void setLivePossibleDate(String livePossibleDate) {
			this.livePossibleDate = livePossibleDate;
		}
		public String getOptions() {
			return options;
		}
		public void setOptions(String options) {
			this.options = options;
		}
		public int getAgentId() {
			return agentId;
		}
		public void setAgentId(int agentId) {
			this.agentId = agentId;
		}
		public String getDongCode() {
			return dongCode;
		}
		public void setDongCode(String dongCode) {
			this.dongCode = dongCode;
		}
		public String getGuCode() {
			return guCode;
		}
		public void setGuCode(String guCode) {
			this.guCode = guCode;
		}
		public String getMagmexp() {
			return magmexp;
		}
		public void setMagmexp(String magmexp) {
			this.magmexp = magmexp;
		}
		public String getDiversionArea() {
			return diversionArea;
		}
		public void setDiversionArea(String diversionArea) {
			this.diversionArea = diversionArea;
		}
		public String getRoomCount() {
			return roomCount;
		}
		public void setRoomCount(String roomCount) {
			this.roomCount = roomCount;
		}
		public String getBathroomCount() {
			return bathroomCount;
		}
		public void setBathroomCount(String bathroomCount) {
			this.bathroomCount = bathroomCount;
		}             
	
}
