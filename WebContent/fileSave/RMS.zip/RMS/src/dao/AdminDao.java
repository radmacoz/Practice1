package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList; 

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class AdminDao {

	private static AdminDao instance = new AdminDao();
	private AdminDao() {}
	public static AdminDao getInstance() {
		return instance;
	} 

	// Connection pool
	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource)
				ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		}catch(Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}
	/**
	 * 구조회
	 * @param startRow
	 * @param endRow
	 * @return
	 */
	public ArrayList<Admin> selectGu() {
		ArrayList<Admin> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql="select GU_CODE , KU_KO_NAME from Gu where use_yn = 'Y'  ORDER BY KU_KO_NAME";
		try{conn = getConnection();
			pstmt  = conn.prepareStatement(sql); 
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Admin admin = new Admin();
				admin.setGuCode(rs.getString("GU_CODE"));
				admin.setGuKoName(rs.getString("KU_KO_NAME"));
				 
			    list.add(admin);
			}
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return list;
	} 
	/**
	 * 관리자의 구 입력 체크 
	 * @param gu
	 * @return
	 */  
	public Boolean selectCheck(Admin admin) {  
        Connection conn = null;  PreparedStatement pstmt = null; 
        ResultSet  rs = null;
        String sql = "select gu_code from GU where use_yn = 'Y' and gu_code = ?";   
		
        try { 
        	conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, admin.getGuCode());               
            rs = pstmt.executeQuery(); 
            if(rs.next()){
            	System.out.println("존재");
            	return false;  
            }
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return true; 
	} 
	
	/**
	 * 관리자의 구 입력
	 * @param gu
	 * @return
	 */  
	public int insert(Admin admin) {  
        Connection conn = null;  PreparedStatement pstmt = null;
         
        String sql = "insert into GU values(?, ?,'Y',sysdate , (SELECT nvl(MAX(GU_NO),0)+1 FROM GU))";   
        int result = 0;  
        try { 
        	conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, admin.getGuCode());  
            pstmt.setString(2, admin.getGuKoName());            
            result = pstmt.executeUpdate();       
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 
	  
	/**
	 * 관리자의 구 입력
	 * @param gu
	 * @return
	 */ 
	public int delete(Admin admin) {  
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0;  
        String sql = "delete from GU where GU_CODE = ?";   
		
        try { 
        	conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, admin.getGuCode());            
            result = pstmt.executeUpdate();       
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	}
	 
	/**
	 * 동조회
	 * @param startRow
	 * @param endRow
	 * @return
	 */
	public ArrayList<Admin> selectDong( String arg) {
		 
		ArrayList<Admin> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql="SELECT * FROM DONG WHERE USE_YN = 'Y' and gu_code = ?  ORDER BY DONG_KO_NAME";
		try{conn = getConnection();
			pstmt  = conn.prepareStatement(sql); 
            pstmt.setString(1, arg);    
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Admin admin = new Admin();
				admin.setDongCode(rs.getString("DONG_CODE"));
				admin.setGuCode(rs.getString("GU_CODE"));
				admin.setDongKoName(rs.getString("DONG_KO_NAME")); 
			    list.add(admin);
			}
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return list;
	} 
	 
	/**
	 * 동조회
	 * @param startRow
	 * @param endRow
	 * @return
	 */
	public ArrayList<Admin> selectAllDong( String arg) {
		 
		ArrayList<Admin> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql="SELECT * FROM DONG WHERE USE_YN = 'Y' ORDER BY  TO_NUMBER(DONG_CODE) DESC";
		try{conn = getConnection();
			pstmt  = conn.prepareStatement(sql);  
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Admin admin = new Admin();
				admin.setDongCode(rs.getString("DONG_CODE"));
				admin.setGuCode(rs.getString("GU_CODE"));
				admin.setDongKoName(rs.getString("DONG_KO_NAME")); 
			    list.add(admin);
			}
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return list;
	} 
	/**
	 * 관리자의 동 입력 체크 
	 * @param gu
	 * @return
	 */  
	public Boolean selectDongCheck(Admin admin) {  
        Connection conn = null;  PreparedStatement pstmt = null; 
        ResultSet  rs = null;
        String sql = "select DONG_CODE from DONG where use_yn = 'Y' and gu_code = ? and DONG_CODE = ?";   
		
        try { 
        	conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, admin.getGuCode());               
            pstmt.setString(2, admin.getDongCode());               
            rs = pstmt.executeQuery(); 
            if(rs.next()){
            	return false; 
            }
             
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return true; 
	} 
	
	/**
	 * 관리자의 동 입력
	 * @param gu
	 * @return
	 */ 
	public int insertDong(Admin admin) {  
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0;  
        String sql = "INSERT INTO DONG VALUES(?, ? , ?, 'Y', SYSDATE , (SELECT NVL(MAX(DONG_NO) , 0)+1  FROM DONG) )";   
         
        try { 
        	conn = getConnection();
            pstmt = conn.prepareStatement(sql); 
            pstmt.setString(1, admin.getDongCode());
            pstmt.setString(2, admin.getGuCode());   
            pstmt.setString(3, admin.getDongKoName());
            result = pstmt.executeUpdate();       
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 

	/**
	 * 관리자의 동 삭제
	 * @param gu
	 * @return
	 */ 
	public int deleteDong(Admin vo) {  
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0;  
        String sql = "delete from DONG where GU_CODE = ? AND DONG_CODE = ?";   
		
        try { 
        	conn = getConnection();
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, vo.getGuCode());            
            pstmt.setString(2, vo.getDongCode());
            result = pstmt.executeUpdate();       
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	}
 
	 /**
	  * 방 타입 모두 조회
	  */
	public ArrayList<Admin> selectAllGoodsKind(){
		 
		ArrayList<Admin> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql="SELECT * FROM GOODS_KIND WHERE USE_YN = 'Y' ORDER BY  TO_NUMBER(KIND_CODE) DESC";
		try{conn = getConnection();
			pstmt  = conn.prepareStatement(sql);  
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Admin admin = new Admin();
				admin.setKindCode(rs.getString("KIND_CODE")); 
				admin.setKindEnName(rs.getString("KIND_EN_NAME")); 
				admin.setKindKoName(rs.getString("KIND_KO_NAME")); 
			    list.add(admin);
			}
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return list; 
	}
	
	/**
	 * 관리자의 동 입력
	 * @param gu
	 * @return
	 */ 
	public int insertGoodsKind(Admin admin) {  
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0;  
        String sql = "INSERT INTO GOODS_KIND VALUES((SELECT NVL(MAX(KIND_No), 0)+1  FROM GOODS_KIND) , ?, ?, ?, 'Y', SYSDATE)";   
         
        try { 
        	conn = getConnection();
            pstmt = conn.prepareStatement(sql); 
            pstmt.setString(1, admin.getKindKoName());
            pstmt.setString(2, admin.getKindEnName());   
            pstmt.setString(3, admin.getKindCode());
            result = pstmt.executeUpdate();       
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 
	
	/**
	 * 방타입 삭제
	 * @param admin
	 * @return
	 */
	public int deleteGoodsKind(Admin admin) {  
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0;  
        String sql = "DELETE FROM GOODS_KIND WHERE KIND_CODE = ?";   
         
        try { 
        	conn = getConnection();
            pstmt = conn.prepareStatement(sql);     
            pstmt.setString(1, admin.getKindCode());
            result = pstmt.executeUpdate();       
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 
	

	/**
	 * 관리자의 sns 입력
	 * @param gu
	 * @return
	 */ 
	@SuppressWarnings("resource")
	public int insertSns(Admin admin) {    
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0; int result1 = 0;    
        int maxPictureNo = 0;
        int maxSnsNo = 0; 
		ResultSet  rs = null;
		
		String sqlP = "SELECT NVL(MAX(PICTURE_NO),0)+1 as PICTURE_NO  FROM PICTURE_FILE "; 
		String sqlMS = "SELECT NVL(MAX(SNS_NO), 0)+1 as SNS_NO FROM TYPE_OF_SNS"; 
			 
        String sqlS = "INSERT INTO TYPE_OF_SNS VALUES(?, ?, ?,'Y', SYSDATE, ?)";   
        String sqlIP = "INSERT INTO PICTURE_FILE VALUES(?, ?, ?, SYSDATE, ?,'S')";
         
        try { 
        	conn = getConnection();

    		pstmt = conn.prepareStatement(sqlP);
    		rs = pstmt.executeQuery();
    		if(rs.next()){
    			maxPictureNo =rs.getInt("PICTURE_NO"); 
    		}

    		pstmt = conn.prepareStatement(sqlMS);
    		rs = pstmt.executeQuery();
    		if(rs.next()){
    			maxSnsNo =rs.getInt("SNS_NO"); 
    		}
            pstmt = conn.prepareStatement(sqlS); 
            pstmt.setInt(1, maxSnsNo);
            pstmt.setString(2, admin.getSnsKoName());
            pstmt.setString(3, admin.getSnsEnName());  
            pstmt.setInt(4, maxPictureNo);  
            result = pstmt.executeUpdate();  
             
            //사진등록
            pstmt = conn.prepareStatement(sqlIP); 
            pstmt.setInt(1, maxPictureNo); 
            pstmt.setString(2, admin.getPictureName());
            pstmt.setString(3, admin.getPicturePath()); 
            pstmt.setInt(4, maxSnsNo);  
            
            result1 = pstmt.executeUpdate();   
            if(result == 1 && result1 == 1){
            	result = 1;
            }else {
            	result = 0;
            }
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 
	

	/**
	 * 관리자의 sns 삭제
	 * @param gu
	 * @return
	 */ 
	@SuppressWarnings("resource")
	public int deleteSns(Admin admin) {  
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0; int result1 = 0;    
        int maxPictureNo = 0;
         
		ResultSet  rs = null;
		String sqlP = "SELECT PICTURE_NO  FROM TYPE_OF_SNS WHERE SNS_NO = ? "; 
			 
        String sqlS = "DELETE FROM TYPE_OF_SNS WHERE SNS_NO = ? ";   
        String sqlDP = "DELETE FROM PICTURE_FILE WHERE PICTURE_NO = ? ";   
         
        try { 
        	conn = getConnection();

    		pstmt = conn.prepareStatement(sqlP);
            pstmt.setInt(1, admin.getSnsNo());
    		rs = pstmt.executeQuery();
    		if(rs.next()){
    			maxPictureNo =rs.getInt("PICTURE_NO"); 
    		}
            pstmt = conn.prepareStatement(sqlS); 
            pstmt.setInt(1, admin.getSnsNo()); 
            result = pstmt.executeUpdate();  
             
            //사진등록
            pstmt = conn.prepareStatement(sqlDP); 
            pstmt.setInt(1, maxPictureNo);   
            result1 = pstmt.executeUpdate();   
            if(result == 1 && result1 == 1){
            	result = 1;
            }else {
            	result = 0;
            }
            
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 
	
	/**
	 * sns 모두 조회
	 * @return
	 */
	public ArrayList<Admin> selectAllSns(){
		 
		ArrayList<Admin> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql=" SELECT DISTINCT A.SNS_NO , A.SNS_KO_NAME,A.SNS_EN_NAME , A.PICTURE_NO , B.PICTURE_PATH "; 
		       sql+=" FROM TYPE_OF_SNS A, PICTURE_FILE B"; 
		       sql+=" WHERE B.GUBUN_NO = A.SNS_NO "; 
		       sql+="  AND B.GUBUN = 'S' "; 
		       sql+="  ORDER BY SNS_NO";  
		       
		    System.out.println(sql);
		try{conn = getConnection();
			pstmt  = conn.prepareStatement(sql);  
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Admin admin = new Admin();
				admin.setSnsNo(rs.getInt("SNS_NO")); 
				admin.setSnsEnName(rs.getString("SNS_EN_NAME")); 
				admin.setSnsKoName(rs.getString("SNS_KO_NAME")); 
				admin.setPictureNo(rs.getInt("PICTURE_NO")); 
				admin.setPicturePath(rs.getString("PICTURE_PATH")); 
			    list.add(admin);
			}
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return list; 
	}
	
	
	/**
	 * 관리자의 옵션 입력
	 * @param gu
	 * @return
	 */ 
	@SuppressWarnings("resource")
	public int insertOption(Admin admin) {    
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0;  
        String sql = "INSERT INTO OPTIONS VALUES((SELECT NVL(MAX(OPTION_NO), 0)+1  FROM OPTIONS) , ?, 'Y', SYSDATE )";   
          
        try { 
        	conn = getConnection(); 
    		 
            pstmt = conn.prepareStatement(sql); 
            pstmt.setString(1, admin.getOptionKoName());   
            result = pstmt.executeUpdate();  
               
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 

	/**
	 * 관리자의 옵션 삭제
	 * @param gu
	 * @return
	 */ 
	@SuppressWarnings("resource")
	public int deleteOption(Admin admin) {    
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0;  
        String sql = "DELETE FROM OPTIONS WHERE OPTION_NO = ?";   
          
        try { 
        	conn = getConnection(); 
    		 
            pstmt = conn.prepareStatement(sql); 
            pstmt.setInt(1, admin.getOptionNo());   
            result = pstmt.executeUpdate();  
               
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 
	
	/**
	 * 옵션 조회 
	 * @return
	 */
	public ArrayList<Admin> selectOption() {
		ArrayList<Admin> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql="SELECT * FROM OPTIONS ORDER BY OPTION_KO_NAME";
		try{conn = getConnection();
			pstmt  = conn.prepareStatement(sql); 
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Admin admin = new Admin();
				admin.setOptionNo(rs.getInt("OPTION_NO"));
				admin.setOptionKoName(rs.getString("OPTION_KO_NAME")); 
			    list.add(admin);
			}
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return list;
	} 
}
