package dao;

import java.util.Date;

public class Agent {
	private int agent_id;
	private String password;
	private String name;
	private String email;
	private String tel;
	private int money;
	private String agent_type;
	private String evaluation;
	private String chat_yn;
	private String del_yn;
	private int sns_no;
	private int dong_code;
	private int gu_code;
	private String agent_comment;
	private Date reg_date;
	
	public int getAgent_id() {
		return agent_id;
	}
	public void setAgent_id(int agent_id) {
		this.agent_id = agent_id;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public int getMoney() {
		return money;
	}
	public void setMoney(int money) {
		this.money = money;
	}
	public String getAgent_type() {
		return agent_type;
	}
	public void setAgent_type(String agent_type) {
		this.agent_type = agent_type;
	}
	public String getEvaluation() {
		return evaluation;
	}
	public void setEvaluation(String evaluation) {
		this.evaluation = evaluation;
	}
	public String getChat_yn() {
		return chat_yn;
	}
	public void setChat_yn(String chat_yn) {
		this.chat_yn = chat_yn;
	}
	public String getDel_yn() {
		return del_yn;
	}
	public void setDel_yn(String del_yn) {
		this.del_yn = del_yn;
	}
	public int getSns_no() {
		return sns_no;
	}
	public void setSns_no(int sns_no) {
		this.sns_no = sns_no;
	}
	public int getDong_code() {
		return dong_code;
	}
	public void setDong_code(int dong_code) {
		this.dong_code = dong_code;
	}
	public int getGu_code() {
		return gu_code;
	}
	public void setGu_code(int gu_code) {
		this.gu_code = gu_code;
	}
	public String getAgent_comment() {
		return agent_comment;
	}
	public void setAgent_comment(String agent_comment) {
		this.agent_comment = agent_comment;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
}
