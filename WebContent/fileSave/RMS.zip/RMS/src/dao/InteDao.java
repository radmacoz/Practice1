package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.*;

import javax.naming.*;

import dao.Inte;

public class InteDao {
	private static InteDao instance=new InteDao();
	private InteDao() {
		
	}
	public static InteDao getInstance() {
		return instance;
	}
	private Connection getConnection() {
		Connection conn=null;
		
		try {
			Context ctx=new InitialContext();
			DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn=ds.getConnection();
		} catch(Exception e) {
			System.out.println("연결실패 : "+e.getMessage());
		}
		
		return conn;
	}
	public int insert(Inte inte) {
		int result=0;
		int inte_number=0;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sqlNum="select nvl(max(inte_number),0)+1 from interior_board";
		String sql="INSERT INTO INTERIOR_BOARD VALUES(?,?,SYSDATE,?,?,?,'N',0,?,?,?)";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sqlNum);
			rs=pstmt.executeQuery();
			if(rs.next())
				inte_number=rs.getInt(1);
			pstmt.close();
			
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setInt(1,inte_number);
			pstmt.setString(2,inte.getInte_title());
			pstmt.setString(3,inte.getInte_type());
			pstmt.setDouble(4,inte.getInte_area());
			pstmt.setString(5,inte.getInte_comment());
			//pstmt.setInt(6,inte.getInte_count());
			pstmt.setString(6,inte.getWrite_ip());
			pstmt.setInt(7,inte.getAgent_id());
			pstmt.setString(8,inte.getPicture_no());
			
			result=pstmt.executeUpdate();
			
			if(result==1) {
				return inte_number;
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();				
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			} 
		}
		
		return result;
	}
	public Inte select(int inte_number) {
		Inte inte=new Inte();
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="select * from interior_board where inte_number=?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,inte_number);
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				inte.setInte_number(rs.getInt(1));
				inte.setInte_title(rs.getString(2));
				inte.setReg_date(rs.getDate(3));
				inte.setInte_type(rs.getString(4));
				inte.setInte_area(rs.getDouble(5));
				inte.setInte_comment(rs.getString(6));
				inte.setInte_del_yn(rs.getString(7));
				inte.setInte_count(rs.getInt(8));
				inte.setWrite_ip(rs.getString(9));
				inte.setAgent_id(rs.getInt(10));
				inte.setPicture_no(rs.getString(11));
			}
			else
				inte=null;			
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();				
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			} 
		}
		
		return inte;
	}
	public List<Inte> select(int startRow, int endRow) {
		List<Inte> list=new ArrayList<>();
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="select * from (select a.*,rownum rn from (select * from interior_board order by inte_number desc) a ) where rn between ? and ?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,startRow);
			pstmt.setInt(2,endRow);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Inte inte=new Inte();
				
				inte.setInte_number(rs.getInt("inte_number"));
				inte.setInte_title(rs.getString("inte_title"));
				inte.setReg_date(rs.getDate("reg_date"));
				inte.setInte_type(rs.getString("inte_type"));
				inte.setInte_area(rs.getDouble("inte_area"));
				inte.setInte_comment(rs.getString("inte_comment"));
				inte.setInte_del_yn(rs.getString("inte_del_yn"));
				inte.setInte_count(rs.getInt("inte_count"));
				inte.setWrite_ip(rs.getString("write_ip"));
				inte.setAgent_id(rs.getInt("agent_id"));
				inte.setPicture_no(rs.getString("picture_no"));
				
				list.add(inte);
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();				
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return list;
	}
	public int total() {
		int total = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null; 
		ResultSet rs = null;
		
		String sql = "select count(*) from interior_board";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				total = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());				
			}
		}
		return total;
	}
	public void updateHit(int inte_number) {
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="update interior_board set inte_count=inte_count+1 where inte_number=?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,inte_number);
			pstmt.executeQuery();
		} catch(Exception e) {
			System.out.println(e.getMessage());			
		} finally {
			try {
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
	}
	public int update(Inte inte) {
		int result=0;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		String sql="update interior_board set inte_title=?,inte_type=?,inte_area=?,inte_comment=?,picture_no=? where inte_number=?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setString(1,inte.getInte_title());
			pstmt.setString(2,inte.getInte_type());
			pstmt.setDouble(3,inte.getInte_area());
			pstmt.setString(4,inte.getInte_comment());
			pstmt.setString(5,inte.getPicture_no());
			pstmt.setInt(6,inte.getInte_number());
			
			result=pstmt.executeUpdate();
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
	}
	public int delete(int inte_number) {
		int result=0;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		String sql="update interior_board set inte_del_yn='y' where inte_number=?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,inte_number);
			result=pstmt.executeUpdate();
		} catch(Exception e) {
			System.out.println(e.getMessage());			
		} finally {
			try {
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
	}
}


















