package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class PictureDao {
	private static PictureDao instance=new PictureDao();
	private PictureDao() {
		
	}
	public static PictureDao getInstance() {
		return instance;
	}
	private Connection getConnection() {
		Connection conn=null;
		
		try {
			Context ctx=new InitialContext();
			DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn=ds.getConnection();
		} catch(Exception e) {
			System.out.println("연결실패 : "+e.getMessage());
		}
		
		return conn;
	}
	public int insert(Picture picture) {
		int result=0;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="INSERT INTO PICTURE_FILE VALUES((SELECT NVL(MAX(PICTURE_NO),0)+1 FROM PICTURE_FILE),?,?,SYSDATE,?,?)";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setString(1,picture.getPicture_name());
			pstmt.setString(2,picture.getPicture_path());
			pstmt.setInt(3,picture.getGubun_no());
			pstmt.setString(4,picture.getGubun());
			
			System.out.println("33333333333333333333 DAO picture.getPicture_name() 값 : "+picture.getPicture_name());
			System.out.println("33333333333333333333 DAO picture.getPicture_path 값 : "+picture.getPicture_path());
			System.out.println("33333333333333333333 DAO picture.getGubun_no() 값 : "+picture.getGubun_no());
			System.out.println("33333333333333333333 DAO picture.getGubun() 값 : "+picture.getGubun());
			
			result=pstmt.executeUpdate();				
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();				
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			} 
		}
		
		return result;
	}
	public Picture select(int gubun_no) {
		Picture picture=new Picture();
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="select * from picture_file where gubun_no=?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,gubun_no);
			rs=pstmt.executeQuery();
			
			if(rs.next()) {
				picture.setPicture_no(rs.getInt(1));
				picture.setPicture_name(rs.getString(2));
				picture.setPicture_path(rs.getString(3));
				picture.setReg_date(rs.getDate(4));
				picture.setGubun_no(rs.getInt(5));
				picture.setGubun(rs.getString(6));
			}
			else
				picture=null;
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();				
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return picture;
	}
}