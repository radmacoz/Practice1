package dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.sql.*;
import javax.naming.*;

import dao.Agent;

public class AgentDao {
	private static AgentDao instance=new AgentDao();
	private AgentDao() {
		
	}
	public static AgentDao getInstance() {
		return instance;
	}
	private Connection getConnection() {
		Connection conn=null;
		
		try {
			Context ctx=new InitialContext();
			DataSource ds=(DataSource)ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn=ds.getConnection();
		} catch(Exception e) {
			System.out.println("연결실패 : "+e.getMessage());
		}
		
		return conn;
	}
	public int confirmId(int agent_id) {
		int result=1;
		
		String sql="select agent_id from agent_member where agent_id=?";
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,agent_id);
			rs=pstmt.executeQuery();
			
			if(rs.next())
				result=1;
			else
				result=0;
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();				
			} catch(Exception e) {
				System.out.println(e.getMessage());				
			}
		}
		return result;
	}
	public Agent select(int agent_id) {
		Agent agent=new Agent();
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="select * from agent_member where agent_id=?";
		
		System.out.println("111111111111111111111111");
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,agent_id);
			rs=pstmt.executeQuery();
			
			System.out.println("2222222222222222222222");
			
			if(rs.next()) {
				agent.setAgent_id(rs.getInt(1));
				agent.setPassword(rs.getString(2));
				agent.setName(rs.getString(3));
				agent.setEmail(rs.getString(4));
				agent.setTel(rs.getString(5));
				agent.setMoney(rs.getInt(6));
				agent.setAgent_type(rs.getString(7));
				agent.setEvaluation(rs.getString(8));
				agent.setChat_yn(rs.getString(9));
				agent.setDel_yn(rs.getString(10));
				agent.setSns_no(rs.getInt(11));
				agent.setDong_code(rs.getInt(12));
				agent.setGu_code(rs.getInt(13));
				agent.setAgent_comment(rs.getString(14));
				agent.setReg_date(rs.getDate(15));
			}
			else
				agent=null;
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();				
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		System.out.println("3333333333333333333333333333");
		return agent;
	}
	public int insert(Agent agent) {
		int result=0;
		int agent_id=0;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sqlNum="select nvl(max(agent_id),0)+1 from agent_member";
		String sql="INSERT INTO agent_member VALUES(?,?,?,?,?,?,?,?,?,'N',?,?,?,?,SYSDATE)";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sqlNum);
			rs=pstmt.executeQuery();
			if(rs.next())
				agent_id=rs.getInt(1);
			pstmt.close();
			
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setInt(1,agent_id);
			pstmt.setString(2,agent.getPassword());
			pstmt.setString(3,agent.getName());
			pstmt.setString(4,agent.getEmail());
			pstmt.setString(5,agent.getTel());
			pstmt.setInt(6,agent.getMoney());
			pstmt.setString(7,agent.getAgent_type());
			pstmt.setString(8,agent.getEvaluation());
			pstmt.setString(9,agent.getChat_yn());
			pstmt.setInt(10,agent.getSns_no());
			pstmt.setInt(11,agent.getDong_code());
			pstmt.setInt(12,agent.getGu_code());
			pstmt.setString(13,agent.getAgent_comment());
			
			result=pstmt.executeUpdate();
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();				
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			} 
		}
		
		return result;
	}
	public List<Agent> select(int startRow, int endRow) {
		List<Agent> list=new ArrayList<>();
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="select * from (select a.*,rownum rn from (select * from agent_member order by agent_id desc) a ) where rn between ? and ?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,startRow);
			pstmt.setInt(2,endRow);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Agent agent=new Agent();
				
				agent.setAgent_id(rs.getInt("agent_id"));
				agent.setPassword(rs.getString("password"));
				agent.setName(rs.getString("name"));
				agent.setEmail(rs.getString("email"));
				agent.setTel(rs.getString("tel"));
				agent.setMoney(rs.getInt("money"));
				agent.setAgent_type(rs.getString("agent_type"));
				agent.setEvaluation(rs.getString("evaluation"));
				agent.setChat_yn(rs.getString("chat_yn"));
				agent.setDel_yn(rs.getString("del_yn"));
				agent.setSns_no(rs.getInt("sns_no"));
				agent.setDong_code(rs.getInt("dong_code"));
				agent.setGu_code(rs.getInt("gu_code"));
				agent.setAgent_comment(rs.getString("agent_comment"));
				
				list.add(agent);
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();				
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return list;
	}
	public int total() {
		int total = 0;
		
		Connection conn = null;
		PreparedStatement pstmt = null; 
		ResultSet rs = null;
		
		String sql = "select count(*) from agent_member";
		
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				total = rs.getInt(1);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());				
			}
		}
		return total;
	}
	public int update(Agent agent) {
		int result=0;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		String sql="update agent_member set email=?,tel=?,sns_no=?,agent_type=?,chat_yn=?,agent_comment=? where agent_id=?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			
			pstmt.setString(1,agent.getEmail());
			pstmt.setString(2,agent.getTel());
			pstmt.setInt(3,agent.getSns_no());
			pstmt.setString(4,agent.getAgent_type());
			pstmt.setString(5,agent.getChat_yn());
			pstmt.setString(6,agent.getAgent_comment());
			pstmt.setInt(7,agent.getAgent_id());
			
			result=pstmt.executeUpdate();
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
	}
	public int delete(int agent_id) {
		int result=0;
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		
		String sql="update agent_member set del_yn='y' where agent_id=?";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,agent_id);
			result=pstmt.executeUpdate();
		} catch(Exception e) {
			System.out.println(e.getMessage());			
		} finally {
			try {
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		return result;
	}
	public int check(int agent_id, String password) {
		int result=0;
		String sql="select password from agent_member where agent_id=? and (del_yn='n' or del_yn='N')";
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			pstmt.setInt(1,agent_id);
			rs=pstmt.executeQuery();
			if(rs.next()) {
				String dbPass=rs.getString("password");	// db에 있는 것
				if(dbPass.equals(password))				// 화면에서 입력한 것
					result=1;
				else
					result=0;
			}
			else
				result=-1;	// id가 없음
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();
			} catch(Exception e) {
				System.out.println(e.getMessage());
			} 
		}
		return result;
	}
	public Agent selectList(int agent_id, String password) {
		Agent agent=new Agent();

		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rs = null;

		String sql="select * from agent_member where agent_id=? and password=?";

		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1,agent_id);
			pstmt.setString(2,password);
			rs = pstmt.executeQuery();
			if(rs.next()) {

//				agent.set (rs.getInt("agent_id"));
//				agent.set (rs.getInt("agent_id"));
//				agent.set (rs.getInt("agent_id"));

			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if (rs != null)
					rs.close();
				if (pstmt != null)
					pstmt.close();
				if (conn != null)
					conn.close();
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}		
		}
		return agent;
	}
	public List<Agent> select() {
		List<Agent> list=new ArrayList<>();
		
		Connection conn=null;
		PreparedStatement pstmt=null;
		ResultSet rs=null;
		
		String sql="select * from agent_member";
		
		try {
			conn=getConnection();
			pstmt=conn.prepareStatement(sql);
			rs = pstmt.executeQuery();
			while(rs.next()) {
				Agent agent=new Agent();
				
				agent.setAgent_id(rs.getInt("agent_id"));
				agent.setPassword(rs.getString("password"));
				agent.setName(rs.getString("name"));
				agent.setEmail(rs.getString("email"));
				agent.setTel(rs.getString("tel"));
				agent.setMoney(rs.getInt("money"));
				agent.setAgent_type(rs.getString("agent_type"));
				agent.setEvaluation(rs.getString("evaluation"));
				agent.setChat_yn(rs.getString("chat_yn"));
				agent.setDel_yn(rs.getString("del_yn"));
				agent.setSns_no(rs.getInt("sns_no"));
				agent.setDong_code(rs.getInt("dong_code"));
				agent.setGu_code(rs.getInt("gu_code"));
				agent.setAgent_comment(rs.getString("agent_comment"));
				
				list.add(agent);
			}
		} catch(Exception e) {
			System.out.println(e.getMessage());
		} finally {
			try {
				if(rs!=null)
					rs.close();
				if(pstmt!=null)
					pstmt.close();
				if(conn!=null)
					conn.close();				
			} catch(Exception e) {
				System.out.println(e.getMessage());
			}
		}
		
		return list;
	}
}













