package dao;

import java.sql.Date;

public class Inte {
	private int inte_number;
	private String inte_title;
	private Date reg_date;
	private String inte_type;
	private double inte_area;
	private String inte_comment;
	private String inte_del_yn;
	private int inte_count;
	private String write_ip;
	private int agent_id;
	private String picture_no;
	
	public int getInte_number() {
		return inte_number;
	}
	public void setInte_number(int inte_number) {
		this.inte_number = inte_number;
	}
	public String getInte_title() {
		return inte_title;
	}
	public void setInte_title(String inte_title) {
		this.inte_title = inte_title;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
	public String getInte_type() {
		return inte_type;
	}
	public void setInte_type(String inte_type) {
		this.inte_type = inte_type;
	}
	public double getInte_area() {
		return inte_area;
	}
	public void setInte_area(double inte_area) {
		this.inte_area = inte_area;
	}
	public String getInte_comment() {
		return inte_comment;
	}
	public void setInte_comment(String inte_comment) {
		this.inte_comment = inte_comment;
	}
	public String getInte_del_yn() {
		return inte_del_yn;
	}
	public void setInte_del_yn(String inte_del_yn) {
		this.inte_del_yn = inte_del_yn;
	}
	public int getInte_count() {
		return inte_count;
	}
	public void setInte_count(int inte_count) {
		this.inte_count = inte_count;
	}
	public String getWrite_ip() {
		return write_ip;
	}
	public void setWrite_ip(String write_ip) {
		this.write_ip = write_ip;
	}
	public int getAgent_id() {
		return agent_id;
	}
	public void setAgent_id(int agent_id) {
		this.agent_id = agent_id;
	}
	public String getPicture_no() {
		return picture_no;
	}
	public void setPicture_no(String picture_no) {
		this.picture_no = picture_no;
	}
}