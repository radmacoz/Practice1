package dao;

import java.util.Date;

public class Picture {
	private int picture_no;
	private String picture_name;	//20 -> 100
	private String picture_path;	//50 -> 100
	private Date reg_date;
	private int gubun_no;
	private String gubun;			//20
	
	public int getPicture_no() {
		return picture_no;
	}
	public void setPicture_no(int picture_no) {
		this.picture_no = picture_no;
	}
	public String getPicture_name() {
		return picture_name;
	}
	public void setPicture_name(String picture_name) {
		this.picture_name = picture_name;
	}
	public String getPicture_path() {
		return picture_path;
	}
	public void setPicture_path(String picture_path) {
		this.picture_path = picture_path;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
	public int getGubun_no() {
		return gubun_no;
	}
	public void setGubun_no(int gubun_no) {
		this.gubun_no = gubun_no;
	}
	public String getGubun() {
		return gubun;
	}
	public void setGubun(String gubun) {
		this.gubun = gubun;
	}
}