package dao;

import java.sql.Date;

public class AgentEval {
	private int eval_number;
	private Date reg_date;
	private String eval_comment;
	private double eval_score;
	private String write_ip;
	private String member_id;
	private int agent_id;
	
	public int getEval_number() {
		return eval_number;
	}
	public void setEval_number(int eval_number) {
		this.eval_number = eval_number;
	}
	public Date getReg_date() {
		return reg_date;
	}
	public void setReg_date(Date reg_date) {
		this.reg_date = reg_date;
	}
	public String getEval_comment() {
		return eval_comment;
	}
	public void setEval_comment(String eval_comment) {
		this.eval_comment = eval_comment;
	}
	public double getEval_score() {
		return eval_score;
	}
	public void setEval_score(double eval_score) {
		this.eval_score = eval_score;
	}
	public String getWrite_ip() {
		return write_ip;
	}
	public void setWrite_ip(String write_ip) {
		this.write_ip = write_ip;
	}
	public String getMember_id() {
		return member_id;
	}
	public void setMember_id(String member_id) {
		this.member_id = member_id;
	}
	public int getAgent_id() {
		return agent_id;
	}
	public void setAgent_id(int agent_id) {
		this.agent_id = agent_id;
	}
}