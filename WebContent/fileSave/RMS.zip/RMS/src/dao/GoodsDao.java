package dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class GoodsDao {
	private static GoodsDao instance = new GoodsDao();

	private GoodsDao() {
	}

	public static GoodsDao getInstance() {
		return instance;
	}

	// Connection pool
	private Connection getConnection() {
		Connection conn = null;
		try {
			Context ctx = new InitialContext();
			DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/OracleDB");
			conn = ds.getConnection();
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return conn;
	}

	/**
	 * 매물 입력
	 * 
	 * @param goods
	 * @return
	 */
	public int insertGoods(Goods vo) {
		System.out.println("insertGoods ===  " + vo);
		Connection conn = null;
		PreparedStatement pstmt = null; 
		ResultSet  rs = null; 
		int maxNo = 0;
		String maxSql = "SELECT nvl(MAX(GOODS_NO),0)+1 as maxNo FROM GOODS_INFOR";
		String sql = "INSERT INTO GOODS_INFOR VALUES((SELECT nvl(MAX(GOODS_NO),0)+1 FROM GOODS_INFOR) ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,? ,'Y' ,SYSDATE ,SYSDATE ,? ,? ,? ,? ,? ,? ,?,?)";

		int result = 0;
		try {
			conn = getConnection();
			pstmt = conn.prepareStatement(maxSql);
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				maxNo = Integer.parseInt( rs.getString("maxNo"));
			}
			System.out.println("maxNo  ==  "+ maxNo);
			
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getTitle());
			pstmt.setInt(2, vo.getKindNo());
			pstmt.setBigDecimal(3, vo.getTran());
			pstmt.setBigDecimal(4, vo.getRealLiveAmt());
			pstmt.setBigDecimal(5, vo.getLoan());
			pstmt.setBigDecimal(6, vo.getNowDepositAmt());
			pstmt.setBigDecimal(7, vo.getNowGuarantyAmt());
			pstmt.setBigDecimal(8, vo.getMonthlyAmt());
			pstmt.setBigDecimal(9, vo.getSupplyArea());
			pstmt.setBigDecimal(10, vo.getTotalLayer());
			pstmt.setBigDecimal(11, vo.getApplyLayer());
			pstmt.setBigDecimal(12, vo.getTotalHouseholds());
			pstmt.setString(13, vo.getDirection());
			pstmt.setInt(14, vo.getParkingCount());
			pstmt.setString(15, vo.getCompletionYear());
			pstmt.setString(16, vo.getHeaterType());
			pstmt.setString(17, vo.getFuel());
			pstmt.setString(18, vo.getLivePossibleDate());
			pstmt.setString(19, vo.getOptions()); 
			pstmt.setInt(20, vo.getAgentId());
			pstmt.setString(21, vo.getDongCode());
			pstmt.setString(22, vo.getGuCode());
			pstmt.setString(23, vo.getMagmexp());
			pstmt.setString(24, vo.getDiversionArea());
			pstmt.setString(25, vo.getRoomCount());
			pstmt.setString(26, vo.getBathroomCount());
			pstmt.setString(27, vo.getAddr());
			
			result = pstmt.executeUpdate(); 
			if(result == 1){
				result = maxNo;
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException ex) {
				}
		}
		return result;
	}


	/**
	 * 매물 입력
	 * 
	 * @param goods
	 * @return
	 */
	public int updateGoods(Goods vo) {
 		Connection conn = null;
		PreparedStatement pstmt = null;   
		 
		String sql = "UPDATE GOODS_INFOR SET ";
		sql += " TITLE              =  ?  ";  
		sql += " ,  KIND_NO            = ? "; 
		sql += " ,  TRAN               = ? "; 
		sql += " ,  REAL_LIVE_AMT      = ? "; 
		sql += " ,  LOAN               = ? "; 
		sql += " ,  NOW_DEPOSIT_AMT    = ? "; 
		sql += " ,  NOW_GUARANTY_AMT   = ? "; 
		sql += " ,  MONTHLY_AMT        = ? "; 
		sql += " ,  SUPPLY_AREA        = ? "; 
		sql += " ,  TOTAL_LAYER        = ? "; 
		sql += " ,  APPLY_LAYER        = ? "; 
		sql += " ,  TOTAL_HOUSEHOLDS   = ? "; 
		sql += " ,  DIRECTION          = ? "; 
		sql += " ,  PARKING_COUNT      = ? "; 
		sql += " ,  COMPLETION_YEAR    = ? ";  
		sql += " ,  HEATER_TYPE        = ? "; 
		sql += " ,  FUEL               = ? "; 
		sql += " ,  LIVE_POSSIBLE_DATE = ? "; 
		sql += " ,  OPTIONS            = ? "; 
		sql += " ,  MODIFY_DATE        = sysdate "; 
		sql += " ,  AGENT_ID           = ?  ";   
		sql += " ,  DONG_CODE          = ?  "; 
		sql += " ,  GU_CODE            = ?  ";   
		sql += " ,  MAGMEXP            = ?  ";    
		sql += " ,  DIVERSION_AREA     = ?  "; 
		sql += " ,  ROOM_COUNT         = ?  ";  
		sql += " ,  BATHROOM_COUNT     = ?  "; 
		sql += " ,  ADDR               = ?  "; 
		sql += " WHERE GOODS_NO = ? ";
 
		int result = 0;
		try {
			conn = getConnection();  
			pstmt = conn.prepareStatement(sql);
			
			pstmt.setString(1, vo.getTitle());  
			pstmt.setInt(2, vo.getKindNo()); 
			pstmt.setBigDecimal(3, vo.getTran()); 
			pstmt.setBigDecimal(4, vo.getRealLiveAmt());
			pstmt.setBigDecimal(5, vo.getLoan());
			pstmt.setBigDecimal(6, vo.getNowDepositAmt());
			pstmt.setBigDecimal(7, vo.getNowGuarantyAmt());
			pstmt.setBigDecimal(8, vo.getMonthlyAmt());
			pstmt.setBigDecimal(9, vo.getSupplyArea());
			pstmt.setBigDecimal(10, vo.getTotalLayer());
			pstmt.setBigDecimal(11, vo.getApplyLayer());
			pstmt.setBigDecimal(12, vo.getTotalHouseholds());
			pstmt.setString(13, vo.getDirection());
			pstmt.setInt(14, vo.getParkingCount());
			pstmt.setString(15, vo.getCompletionYear());
			pstmt.setString(16, vo.getHeaterType());
			pstmt.setString(17, vo.getFuel());
			pstmt.setString(18, vo.getLivePossibleDate());
			pstmt.setString(19, vo.getOptions());
			pstmt.setInt(20, vo.getAgentId());
			pstmt.setString(21, vo.getDongCode());
			pstmt.setString(22, vo.getGuCode());
			pstmt.setString(23, vo.getMagmexp());
			pstmt.setString(24, vo.getDiversionArea());
			pstmt.setString(25, vo.getRoomCount());
			pstmt.setString(26, vo.getBathroomCount());
			pstmt.setString(27, vo.getAddr());
			pstmt.setInt(28, vo.getGoodsNo());
			result = pstmt.executeUpdate(); 
			 
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException ex) {
				}
		}
		return result;
	}
	 

	/**
	 * 매물 삭제
	 * 
	 * @param goods
	 * @return
	 */
	public int deleteGoods(Goods vo) {
 		Connection conn = null;
		PreparedStatement pstmt = null; 
		     System.out.println(" dao vo = "+ vo.getGoodsNo());
		String sql = "update  GOODS_INFOR set USE_YN = 'N' , MODIFY_DATE = sysdate WHERE GOODS_NO = ?"; 
 
		int result = 0;
		try {
			conn = getConnection();   
			pstmt = conn.prepareStatement(sql);  
			pstmt.setInt(1, vo.getGoodsNo());
			result = pstmt.executeUpdate(); 
			  System.out.println(" dao result = "+ result);
		} catch (Exception e) {
			System.out.println(e.getMessage());
		} finally {
			if (pstmt != null)
				try {
					pstmt.close();
				} catch (SQLException ex) {
				}
			if (conn != null)
				try {
					conn.close();
				} catch (SQLException ex) {
				}
		}
		return result;
	}
	/**
	 * 관리자의 사진 입력
	 * @param gu
	 * @return
	 */ 
	@SuppressWarnings("resource")
	public int insertPicture(Goods goods) {    
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0; 
         System.out.println(" dao picture insert goods.getMaxNo()  = " + goods.getMaxNo() );
          
	    String sql = "INSERT INTO PICTURE_FILE VALUES((select nvl(max(PICTURE_NO),0)+1 from PICTURE_FILE), ?, ?, SYSDATE, ? , 'G')";
         
        try { 
        	conn = getConnection();
        	 
            //사진등록
            pstmt = conn.prepareStatement(sql); 
            pstmt.setString(1, goods.getPictureName()); 
            pstmt.setString(2, goods.getPicturePath());  
            pstmt.setInt(3, goods.getMaxNo());  
            
            result = pstmt.executeUpdate();   
              
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 
	

	/**
	 * 관리자의 사진 삭제
	 * @param gu
	 * @return
	 */ 
	public int deletePicture(Goods goods) {    
        Connection conn = null;  PreparedStatement pstmt = null;
        int result = 0;  
	    String sql = "DELETE FROM PICTURE_FILE WHERE GUBUN_NO = ? AND GUBUN = 'G'";
         
        try { 
        	conn = getConnection();  
            pstmt = conn.prepareStatement(sql); 
            pstmt.setInt(1, goods.getGoodsNo()); 
            result = pstmt.executeUpdate();   
             
        } catch(Exception e) {System.out.println(e.getMessage()); 
        } finally {           
            if (pstmt != null) try { pstmt.close(); } catch(SQLException ex) {}
            if (conn  != null) try { conn.close();  } catch(SQLException ex) {}
        }
        return result; 
	} 
	
	/**
	 * 매물 리스트 
	 */
	
	public ArrayList<Goods> selListGoods (Goods vo){
		 
		ArrayList<Goods> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql= "select * from ( ";
		sql+= "    	  select (select count(*) from goods_infor  where  USE_YN = 'Y' ) as to_tal, rownum  as num1,";
		sql+= "    	    a.GOODS_NO  as GOODS_NO                                                    ";
		sql+= "    	  				  , nvl((select PICTURE_NAME from (";
		sql+= "    	  				      select PICTURE_PATH||'/'||PICTURE_NAME  as PICTURE_NAME , GUBUN_NO";
		sql+= "    	  				      from PICTURE_FILE where gubun = 'G'  and substr(PICTURE_NAME , 0, 2) != '06' order by PICTURE_NO asc";
		sql+= "    	  				   ) where GUBUN_NO = a.GOODS_NO and rownum = 1 ) , '') as PICTURE_NAME";
		sql+= "    	  				  , a.addr";
   	    sql+= "    	  				  , a.SUPPLY_AREA";
		sql+= "    	  				  , a.TITLE";
		sql+= "    	  				  , a.TRAN";
		sql+= "    	  				  , a.REAL_LIVE_AMT";
		sql+= "    	  				  , (SELECT NAME||'/'||TEL FROM AGENT_MEMBER";
		sql+= "    	  				      WHERE AGENT_ID = a.AGENT_ID) as agent";
		sql+= "                       , a.KIND_NO";
		sql+= "                       , a.DONG_CODE"; 
		sql+= "    	  			  from GOODS_INFOR a  where a.USE_YN = 'Y' ";
		
	    sql+= "    	  		  order by a.goods_no desc"; 
	    sql+= "    	  		) where  KIND_NO = decode(? , 0, KIND_NO,?) and DONG_CODE like ? and num1 >= ? and num1 <=  ?";
	     
		try{
			conn = getConnection();
			pstmt  = conn.prepareStatement(sql); 
			 
			pstmt.setInt(1, vo.getInKindNo() );
			pstmt.setInt(2, vo.getInKindNo() );
			pstmt.setString(3, vo.getInDongCode()+'%');
			pstmt.setInt(4, vo.getStart_no());
			pstmt.setInt(5, vo.getEnd_no());
			
			rs = pstmt.executeQuery();
			
			while(rs.next()) {
				Goods goodsVo = new Goods();
				goodsVo.setToTal(rs.getInt("to_tal"));
				goodsVo.setGoodsNo(rs.getInt("GOODS_NO"));
			    goodsVo.setPictureName(rs.getString("PICTURE_NAME"));
			    goodsVo.setAddr(rs.getString("addr"));
			    goodsVo.setSupplyArea(rs.getBigDecimal("SUPPLY_AREA"));
			    goodsVo.setTitle(rs.getString("TITLE"));
			    goodsVo.setTran(rs.getBigDecimal("TRAN"));
			    goodsVo.setRealLiveAmt(rs.getBigDecimal("REAL_LIVE_AMT"));
			    goodsVo.setAgent(rs.getString("agent"));
			    goodsVo.setKindNo(rs.getInt("KIND_NO"));
			    goodsVo.setDongCode(rs.getString("DONG_CODE"));
				list.add(goodsVo);
			}
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return list;  
	}
	
	/**
	 * 매물 정보 조회
	 * @param vo
	 * @return
	 */
	public Goods selGoodsInfo (Goods vo){

		Goods outVo = new Goods();
		ArrayList<Goods> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql= " SELECT A.* ";
		sql += ", (SELECT KIND_KO_NAME FROM GOODS_KIND WHERE KIND_NO = A.KIND_NO) AS KIND_KO_NAME";
		sql += ", (SELECT KU_KO_NAME FROM GU WHERE GU_CODE = A.GU_CODE) AS KU_KO_NAME ";
		sql += ", (SELECT DONG_KO_NAME FROM DONG WHERE DONG_CODE = A.DONG_CODE) AS DONG_KO_NAME";
		sql += ", (SELECT NAME FROM AGENT_MEMBER WHERE AGENT_ID = A.AGENT_ID) AS AGENT_NAME";
		sql += " FROM GOODS_INFOR A";
		sql += " WHERE GOODS_NO = ?";
		
		System.out.println("sql dao = " + sql);
		try{conn = getConnection();
			pstmt  = conn.prepareStatement(sql); 
			 
			pstmt.setInt(1, vo.getGoodsNo());  
			rs = pstmt.executeQuery();  
			if(rs.next()){ 
				 outVo.setGoodsNo(rs.getInt("GOODS_NO"));
			     outVo.setTitle(rs.getString("TITLE"));  
			     outVo.setKindNo(rs.getInt("KIND_NO"));
			     outVo.setKindKoName(rs.getString("KIND_KO_NAME"));
			    
				 outVo.setTran( rs.getBigDecimal("TRAN") );                                                 
				 outVo.setRealLiveAmt(rs.getBigDecimal("REAL_LIVE_AMT"));                                     
				 outVo.setLoan(rs.getBigDecimal("LOAN"));
				 outVo.setNowDepositAmt(rs.getBigDecimal("NOW_DEPOSIT_AMT"));                                              
				 outVo.setNowGuarantyAmt(rs.getBigDecimal("NOW_GUARANTY_AMT"));                                    
				 outVo.setMonthlyAmt(rs.getBigDecimal("MONTHLY_AMT"));                                       
				 outVo.setSupplyArea(rs.getBigDecimal("SUPPLY_AREA"));                                           
				 outVo.setTotalLayer(rs.getBigDecimal("TOTAL_LAYER"));                                           
				 outVo.setApplyLayer(rs.getBigDecimal("APPLY_LAYER"));                                           
				 outVo.setTotalHouseholds(rs.getBigDecimal("TOTAL_HOUSEHOLDS"));                                        
				 outVo.setDirection(rs.getString("DIRECTION"));                                       
				 outVo.setParkingCount(rs.getInt("PARKING_COUNT"));                                          
				 outVo.setCompletionYear(rs.getString("COMPLETION_YEAR"));                                     
				 outVo.setHeaterType(rs.getString("HEATER_TYPE"));                                       
				 outVo.setFuel(rs.getString("FUEL"));                                                 
				 outVo.setLivePossibleDate(rs.getString("LIVE_POSSIBLE_DATE"));                                           
				 outVo.setOptions(rs.getString("OPTIONS")); 				 
				 outVo.setAgentId(rs.getInt("AGENT_ID"));
				 outVo.setAgentName(rs.getString("AGENT_NAME"));
	 			 outVo.setDongCode(rs.getString("DONG_CODE"));   
	 			 outVo.setDongKoName(rs.getString("DONG_KO_NAME"));
				 outVo.setGuCode(rs.getString("GU_CODE"));                                                 
				 outVo.setKuKoNanme(rs.getString("KU_KO_NAME"));
				 outVo.setMagmexp(rs.getString("MAGMEXP"));                                                  
				 outVo.setDiversionArea(rs.getString("DIVERSION_AREA"));                                           
				 outVo.setRoomCount(rs.getString("ROOM_COUNT"));                                         
				 outVo.setBathroomCount(rs.getString("BATHROOM_COUNT"));
				 outVo.setAddr(rs.getString("ADDR"));
				 
			}
		
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return outVo;  
	}
	
	 /**
	  * 사진 조회 
	  * @param vo
	  * @return
	  */
	public ArrayList<Goods> selListPicture (Goods vo){ 
		ArrayList<Goods> list = new ArrayList<>();
		Connection conn = null; PreparedStatement pstmt = null; 
		ResultSet  rs = null;
		String sql = " select PICTURE_PATH||'/'||PICTURE_NAME as PICTURE_PATH,  PICTURE_NAME from PICTURE_FILE ";
			   sql += "  where GUBUN_NO = ? and GUBUN = 'G' ";
			   sql += " group by PICTURE_PATH , PICTURE_NAME";
			   
	    System.out.println("sql dao = " + sql);
		try{
			
			conn = getConnection();
			pstmt  = conn.prepareStatement(sql); 
 
		    pstmt.setInt(1, vo.getGoodsNo() ); 
			rs = pstmt.executeQuery();
			 
			 System.out.println("sql dao 1 "  );
			 while(rs.next()) {
				Goods goodsVo = new Goods();  
			     goodsVo.setPicturePath(rs.getString("PICTURE_PATH"));   
			     goodsVo.setPictureName(rs.getString("PICTURE_NAME"));  
				 list.add(goodsVo); 
			 } 
			   
		}catch(Exception e) { System.out.println(e.getMessage());			
		}finally {
			try {if (rs != null) rs.close();
				 if (pstmt != null) pstmt.close();
				 if (conn != null)  conn.close();
			}catch(Exception e) {}
		}
		return list;  
	}

}

