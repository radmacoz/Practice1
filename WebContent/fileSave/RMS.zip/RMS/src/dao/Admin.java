package dao;

public class Admin {
	private String guCode =""; 
	private String guKoName = ""; 
	private String dongCode = ""; 
	private String dongKoName = "";
	private String kindCode = "";
	private String kindKoName = "";
	private String kindEnName = "";
	 
	private String snsKoName = "";
	private String snsEnName = "";
	private String pictureName = "";
	private String picturePath = "";
	private int pictureNo = 0;
	private int snsNo = 0;
    private int optionNo = 0;
    private String optionKoName = "";
	
	public int getOptionNo() {
		return optionNo;
	}
	public void setOptionNo(int optionNo) {
		this.optionNo = optionNo;
	}
	public String getOptionKoName() {
		return optionKoName;
	}
	public void setOptionKoName(String optionKoName) {
		this.optionKoName = optionKoName;
	}
	public int getPictureNo() {
		return pictureNo;
	}
	public void setPictureNo(int pictureNo) {
		this.pictureNo = pictureNo;
	}
	public int getSnsNo() {
		return snsNo;
	}
	public void setSnsNo(int snsNo) {
		this.snsNo = snsNo;
	}
	public String getKindEnName() {
		return kindEnName;
	}
	public void setKindEnName(String kindEnName) {
		this.kindEnName = kindEnName;
	}
	public String getSnsKoName() {
		return snsKoName;
	}
	public void setSnsKoName(String snsKoName) {
		this.snsKoName = snsKoName;
	}
	public String getSnsEnName() {
		return snsEnName;
	}
	public void setSnsEnName(String snsEnName) {
		this.snsEnName = snsEnName;
	}
	public String getPictureName() {
		return pictureName;
	}
	public void setPictureName(String pictureName) {
		this.pictureName = pictureName;
	}
	public String getPicturePath() {
		return picturePath;
	}
	public void setPicturePath(String picturePath) {
		this.picturePath = picturePath;
	}
	public String getKindCode() {
		return kindCode;
	}
	public void setKindCode(String kindCode) {
		this.kindCode = kindCode;
	}
	public String getKindKoName() {
		return kindKoName;
	}
	public void setKindKoName(String kindKoName) {
		this.kindKoName = kindKoName;
	}
	public String getGuCode() {
		return guCode;
	}
	public void setGuCode(String guCode) {
		this.guCode = guCode;
	}
	public String getGuKoName() {
		return guKoName;
	}
	public void setGuKoName(String guKoName) {
		this.guKoName = guKoName;
	}
	public String getDongCode() {
		return dongCode;
	}
	public void setDongCode(String dongCode) {
		this.dongCode = dongCode;
	}
	public String getDongKoName() {
		return dongKoName;
	}
	public void setDongKoName(String dongKoName) {
		this.dongKoName = dongKoName;
	} 
	
	
}
